const theButton = document.querySelector(".the-button");
const popup = document.querySelector(".popup");
const closeButton = document.querySelector(".close-icon");
const prevImage = document.querySelector(".left-arrow");
const nextImage = document.querySelector(".right-arrow");
const sizeSelect = document.querySelector(".form__size");
const variantSelect = document.querySelector(".variant-select");
const formAvailability = document.querySelector(".form__availability");
const avaiableTemplate = document.querySelector(".temp-available");
const unavaiableTemplate = document.querySelector(".temp-unavailable");
const amount = document.querySelector(".amount-input");
const decButton = document.querySelector(".amount-minus");
const incButton = document.querySelector(".amount-plus");
const confirmButton = document.querySelector(".confirm__button > button");
let images = document.querySelectorAll(".image__single");
let currentImage = 0;
let sizesData = [];

theButton.addEventListener("click", () => {
    popup.classList.toggle("flex-center");
})

popup.addEventListener("click", (event) => {
    if (event.target.matches(".popup") || event.target.matches(".close-icon")) {
        popup.classList.toggle("flex-center");
    }
})

nextImage.addEventListener("click", () => {
    if (currentImage < images.length-1) {
        currentImage++;
        images[currentImage-1].classList.remove("image__single--active");
        images[currentImage].classList.add("image__single--active");
    } else {
        currentImage = 0;
        images[images.length-1].classList.remove("image__single--active");
        images[currentImage].classList.add("image__single--active");
    }
})

prevImage.addEventListener("click", () => {
    if (currentImage > 0) {
        currentImage--;
        images[currentImage+1].classList.remove("image__single--active");
        images[currentImage].classList.add("image__single--active");
    } else if (currentImage == 0) {
        currentImage = images.length-1;
        images[0].classList.remove("image__single--active");
        images[currentImage].classList.add("image__single--active");
    }
})

decButton.addEventListener("click", () => {
    amount.stepDown();
})

incButton.addEventListener("click", () => {
    amount.stepUp();
})

const fetchInfo = async () => {
    const res = await fetch("http://127.0.0.1:5500/xbox.json");
    const info = await res.json();
    const sizes = info.sizes.items;
    const variants = info.multiversions[0].items;

    Object.values(sizes).forEach(size => {
        sizesData.push(
            {
                dataName: size.name,
                size: size.description,
                amount: size.amount,
                price: size.prices.price_retail
            }
        )
    })

    sizesData.sort((a,b) => a.size.localeCompare(b.size));

    sizesData.forEach((data, index) => {
        const input = document.createElement("input");
        input.classList.add("size-radio");
        input.type = "radio";
        input.id = data.dataName;
        input.name = "sizes";
        input.setAttribute("form", "confirm-form");
        if (index == 0) {
            input.checked = true;
        }
        input.addEventListener("click", () => {
            let availableAmount = data.amount;
            amount.max = availableAmount;
            if (availableAmount > 0) {
                amount.min = 1;
                amount.value = 1;
                formAvailability.innerHTML = "";
                formAvailability.appendChild(avaiableTemplate.content.cloneNode(true));
                confirmButton.disabled = false;
                confirmButton.classList.remove("button--inactive");
            } else {
                amount.min = 0;
                amount.value = 0;
                formAvailability.innerHTML = "";
                formAvailability.appendChild(unavaiableTemplate.content.cloneNode(true));
                confirmButton.disabled = true;
                confirmButton.classList.add("button--inactive");
            }
        })
        const label = document.createElement("label");
        label.classList.add("size-label", "cursor-pointer");
        label.htmlFor = data.dataName;
        label.setAttribute("form", "confirm-form");
        label.innerText = data.size;
        sizeSelect.appendChild(input);
        sizeSelect.appendChild(label);
    })

    Object.values(variants).forEach(variant => {
        const option = document.createElement("option");
        option.innerText = Object.values(variant.values)[0].name;
        variantSelect.appendChild(option);
    })
}

fetchInfo();
//console.log(sizesData);